[![Python](https://img.shields.io/pypi/pyversions/tensorflow.svg?style=plastic)](https://badge.fury.io/py/tensorflow) [![PyPI](https://badge.fury.io/py/tensorflow.svg)](https://badge.fury.io/py/tensorflow)

<h1> <center>AutoNeuro</center></h1>

<div align="center">
  <img src="Auto.png">
</div>

AutoNeuro is an automated machine learning application built using python 3.7. It allows users to build production ready ML models with ease and efficiency.
This is an open source project owned by [iNeuron] (https://ineuron.ai). See the [About us](https://autoneuro.ml/GettingStarted/GettingStarted/) page for more information.

website: https://autoneuro.ml


### Dependencies

AutoNeuro requires:
* Python 3.7

---
**NOTE**

ALl the Dependencies will be taken care by the package.

---
<br>

## User Installation
The easiest way to install autoNeuro is using ```Pip```
```
pip install AutoNeuro
```

The documentation includes more detailed [installation instructions](https://autoneuro.ml/GettingStarted/How%20to%20use/)

## Change log
See the [change log]() for a history of notable changes to AutoNeuro.

## Development
We welcome new contributors of all experience levels. The [Development Guide](https://autoneuro.ml/ForDevelopers/MethodsforModelbuilding/) has detaled information about the contributing code, documentation, tests, and more. 
We have included only the basic information in the README file.

### Important links
* Official source code repo: https://github.com/viratsagar/Autoneuro
* Download releases: 
* Issue Tracker:

### Source code
You can check the latest sources with the command:
```
git clone https://github.com/viratsagar/Autoneuro.git
```
### Contributing
To learn more about making a contribution to Autoneuro, please see our
[Contributing guide](https://autoneuro.ml/Contributingtoautoneuro/Contributingtoautoneuro/)

If you don't know where to start, please join our community on Ineuron and ask us. We will help you get started!

### Testing
After installation, you can launch the test suite from outside the source directory (you will need to have pytest >= 5.0.1 installed):
```
pytest AutoNeuro
```
### Submitting a Pull Request
Before opening a Pull Request, have a look at the full Contributing page to make sure your code 
complies with our guidelines: https://autoneuro.ml/Contributingtoautoneuro/Contributingtoautoneuro/

## Help and Support
https://autoneuro.ml/Contributingtoautoneuro/Contributingtoautoneuro/

### Documentation
* HTML documentation (stable release): https://autoneuro.ml
* HTML documentation (development version): https://autoneuro.ml
* FAQ:

### Communication
* Mailing list: Subscribe our [email list]() to receive announcements.
* IRC channel: 
* Gitter: 
* Twitter: You can also follow us on Twitter [@autoneuro](https://mobile.twitter.com/Sudhans74624324) for the latest news.
* Stack Overflow: 
* Website: http://ineuron.ai/

## Citation
If you use AutoNeuro in a offical production, we would appreciate citations: 

## License
[AutoNeuro License](https://github.com/nabeelfahmi12/AutoNeuro-Documentation/blob/master/docs/License.md)

