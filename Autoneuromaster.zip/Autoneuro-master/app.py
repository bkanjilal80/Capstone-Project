from flask import Flask, render_template, request, send_file
import pandas as pd
import json
import configparser

from dataLoad.data_loader import DataGetter
from dataPreprocessing.preProcess import Preprocessor
from dataVisualization.visualization import DataVisualization
from modelTraining.classificationModels import ClassificationModelTuner
from modelTraining.regressionModels import RegressionModelTuner
from prediction.predict import Prediction
#from deployment.aws_deployment import AWSAutoDeploy

app = Flask(__name__)

# All class instantiation
data_getter = DataGetter()
preprocessor = Preprocessor()
# visuals = DataVisualization()
classification_model = ClassificationModelTuner()
regression_model = RegressionModelTuner()
prediction = Prediction()
#deploy = AWSAutoDeploy()
Predconfig = configparser.ConfigParser()

# cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'r+')
# Predconfig.read("ClientDeploymentFiles/prediction_configurations")

@app.route('/', methods=['GET'])
def index():
    """
                              Method Name: index
                              Description: starting point of app.py code which redirect you to the index.html page
                              where you can select the format of data and upload it for further process
                              Output: index html page.
                              On Failure: Raise Exception
                              Written By: iNeuron Intelligence
                              Revisions: None
                              """
    return render_template('index.html')

@app.route('/')
def upload_form():
    return render_template('prediction_results.html')


@app.route('/download')
def download_file():

    path = "Admission_Prediction.csv"
    return send_file(path, as_attachment=True)


@app.route('/load_data', methods=['POST'])
def load_data_from_source():
    """
                                Method Name: load_data_from_source
                                Description: describes data frame infomation as below:
                                             	The number of rows
                                             	The number of columns
                                             	Number of missing values per column and their percentage
                                             	Total missing values and it’s percentage
                                             	Number of categorical columns and their list
                                             	Number of numerical columns and their list
                                             	Number of duplicate rows
                                             	Number of columns with zero standard deviation and their list
                                                 Size occupied in RAM
                                Output: tables.html page
                                On Failure: Raise Exception
                                Written By: iNeuron Intelligence
                                Revisions: None
                              """
    try:
        file = request.files['filename']  # File can be obtained from request.files
        file_type = request.form['source']  # File Source can be obtained here
        # print(file,file_type)
        if request.form['delimiter'] is not None:
            delimeter = str(request.form['delimiter'])
        global dataset  # Declare global variable
        data_getter = DataGetter()  # instantiation for genrating preprocessing logs
        dataset = data_getter.get_data(file_type, file,
                                       delimeter)  # call get_data method, it will load the dataset into dataframe
        preprocessor = Preprocessor()  # instantiation for genrating preprocessing logs
        data_profile = preprocessor.get_data_profile(dataset)  # call get_data_profile
        # print(data.head())
        # render template tables.html with the respective dataset

    except Exception as e:
        return render_template("index.html", message="No file selected")
    return render_template('tables.html', tables=[dataset.head(10).to_html(classes='data', header="True")],
                           columns=dataset.columns, profile=data_profile)


@app.route('/start_processing', methods=['POST'])
def start_processing():
    """
                                  Method Name: start_processing
                                  Description: receive the problem type and target column and unwanted columns from tables
                                  html page,generates the correlation table and different types of plots
                                  Output: charts.html page
                                  On Failure: Raise Exception
                                  Written By: iNeuron Intelligence
                                  Revisions: None
                                  """

    global problem_type, target_column, unwanted_cols, sym_to_replace, thrsh_null
    problem_type = request.form['problem_type']  # get problem_type, that can be classification or regression
    target_column = request.form['target_column']  # get target column name
    try:
        unwanted_cols = request.form['unwanted_cols']  # get unwanted columns
    except:
        unwanted_cols = []
    if request.form['sym_to_replace'] is not None:
        sym_to_replace = str(request.form['sym_to_replace'])
    else:
        sym_to_replace = None
    if request.form['thrsh_null']:
        thrsh_null = int(request.form['thrsh_null'])
    else:
        thrsh_null = int(100)

    global x, y
    preprocessor = Preprocessor()  # instantiation for genrating prediction logs
    cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'r+')
    Predconfig.read("ClientDeploymentFiles/prediction_configurations")
    Predconfig.set('Prediction', 'problem_type', str(problem_type))
    Predconfig.set('Prediction', 'target_column', str(target_column))
    Predconfig.set('Prediction', 'unwanted_cols', str(unwanted_cols))
    Predconfig.set('Prediction', 'sym_to_replace', str(sym_to_replace))
    Predconfig.set('Prediction', 'thrsh_null', str(thrsh_null))
    Predconfig.set('Prediction', 'dataset', str(dataset.columns.tolist()))
    Predconfig.write(cfgfile)
    cfgfile.close()

    x, y = preprocessor.preprocess(dataset, target_column, unwanted_cols, sym_to_replace,
                                   thrsh_null)  # Calling preprocess method of preprocessor class
    visuals = DataVisualization()  # instatiating object here to initiate logging.
    hmap = visuals.correlation_heatmap(x)
    # balance_plot=visuals.balance_imbalance_check(x,y)
    return render_template('charts.html', hmap=hmap, balance_plot=hmap)


@app.route('/build_model', methods=['POST'])
def build_model():
    """
                                       Method Name: build_model
                                       Description:generates the performance report of both the test and train data
                                       for both the classification and regression problems
                                       Output: model_report.html page in case if any thing fails inside the if condition
                                       then index.html age is returned
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    # if problem type is classification, then get the best model with the classification report, else render index.html
    global used_cols, unused_cols
    used_cols, unused_cols = preprocessor.get_used_columns_for_training(dataset, x)

    cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'r+')
    unused_cols_config=" ".join(unused_cols).replace(" ",",")
    Predconfig.set('Prediction', 'unused_cols', str(unused_cols_config))
    Predconfig.write(cfgfile)
    cfgfile.close()
    if problem_type == 'Classification':
        # classification_model=ClassificationModelTuner()#logs for classification modelling
        model_name, train_classification_report, test_classification_report = classification_model.get_best_model(x, y)
        return render_template('model_report_classification.html', model_name=model_name,
                               train_report=train_classification_report[:len(train_classification_report) - 1],
                               test_report=test_classification_report[:len(test_classification_report) - 1],
                               used_cols=used_cols, unused_cols=unused_cols)
    else:

        model_name, train_reg_report, test_reg_report = regression_model.get_best_model(x, y)

        return render_template('model_report_regression.html', model_name=model_name,
                               train_report=train_reg_report,
                               test_report=test_reg_report,
                               used_cols=used_cols, unused_cols=unused_cols)


@app.route('/try_prediction', methods=['POST'])
def try_predict():
    """
                                       Method Name: try_predict
                                       Description: provides the html page for providing the data for prediction,give your prediction data here.
                                       Output: prediction.html page
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    return render_template('prediction.html')


@app.route('/predict', methods=['POST'])
def predict():
    """
                                       Method Name: predict
                                       Description: takes the prediction data from prediction.html page
                                       and perform same kind of transformation as the train  and test data set
                                       and provides prediction result
                                       Output: prediction_results.html page
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    global prediction_dataset
    try:
        file = request.files['prediction_filename']  # get prediction file
        file_type = request.form['source']  # get file type
        if request.form['delimiter'] is not None:
            delimeter = str(request.form['delimiter'])
        data_getter = DataGetter()
        prediction_dataset = data_getter.get_data(file_type, file, delimeter)  # Matching with function definition
    except:
        try:
            json_data = json.loads(request.form['pred_request'])

            prediction_dataset = pd.read_json(json_data)
        except:
            json_data = None
    prediction = Prediction()
    print(used_cols.tolist())
    prediction_dataset = prediction_dataset.loc[:,used_cols.tolist()]
    print(prediction_dataset.head())
    preds = prediction.predict_results(prediction_dataset, target_column, dataset.columns, unwanted_cols,
                                       sym_to_replace, thrsh_null)  # predict the result for the data loaded

    # render prediction_results.html with the prediction result
    return render_template('prediction_results.html', tables=[preds.head(10).to_html(classes='data', header="True")],
                           columns=preds.columns)


@app.route('/select_cloud', methods=['POST'])
def select_cloud():
    cloud_name = request.form['cloud_name']
    if cloud_name == 'aws':
        return render_template('AWSDeploymentLogin.html')


@app.route('/aws_deploy', methods=['POST'])
def ValidateCredentials():
    try:
        # get values from UI
        Accesskey = request.form['Accesskey']
        Accesspassword = request.form['SecretAccessKey']
        if (Accesskey is not None and Accesspassword is not None):
            url = deploy.ValidateCredentials(Accesskey, Accesspassword, "ap-south-1")
            #return url
            return render_template('aws_url.html',url=url)
        else:
            return "Credentials are Mandatory"
    except Exception as e:
        return render_template('500.html')


if __name__ == '__main__':
    app.run(debug=True)