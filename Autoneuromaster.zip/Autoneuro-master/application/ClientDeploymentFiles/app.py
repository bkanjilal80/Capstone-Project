from flask import Flask, render_template, request
from dataLoad.data_loader import DataGetter
from dataPreprocessing.preProcess import Preprocessor
from prediction.predict import Prediction
import pandas as pd
import json
import configparser


app = Flask(__name__)

@app.route('/', methods=['GET'])
def index():
    """
                              Method Name: index
                              Description: starting point of app.py code which redirect you to the index.html page
                              where you can select the format of data and upload it for further process
                              Output: index html page.
                              On Failure: Raise Exception

                              Written By: iNeuron Intelligence
                              Revisions: None

                              """
    return render_template('prediction.html')

@app.route('/predict', methods=['POST'])
def predict():

    """
                                       Method Name: predict
                                       Description: takes the prediction data from prediction.html page
                                       and perform same kind of transformation as the train  and test data set
                                       and provides prediction result
                                       Output: prediction_results.html page
                                       On Failure: Raise Exception

                                       Written By: iNeuron Intelligence
                                       Revisions: None

                                       """
    global prediction_dataset,dataset
    global problem_type, target_column, unwanted_cols, sym_to_replace, thrsh_null
    try:
        file = request.files['prediction_filename']  # get prediction file
        file_type = request.form['source']  # get file type
        if request.form['delimiter'] is not None:
            delimeter = str(request.form['delimiter'])
        data_getter = DataGetter()
        prediction_dataset = data_getter.get_data(file_type, file, delimeter)  # Matching with function definition
    except:
        try:
            json_data = json.loads(request.form['pred_request'])

            prediction_dataset = pd.read_json(json_data)
        except:
            json_data = None
    prediction = Prediction()
    config = configparser.ConfigParser()
    config.read("prediction_configurations")
    problem_type = config['Prediction']['problem_type']
    target_column = config['Prediction']['target_column']
    dataset = config['Prediction']['dataset']
    unwanted_cols = config['Prediction']['unwanted_cols']
    sym_to_replace = config['Prediction']['sym_to_replace']
    thrsh_null = config['Prediction']['thrsh_null']
    unused_cols=config['Prediction']['unused_cols'].split(",")
    #unused_cols=json.loads(config.get("Prediction","unused_cols"))
    #unused_cols = list(config['Prediction']['unused_cols'])
    cols_to_drop=[]
    for col in unused_cols:
        if col not in unwanted_cols:
            if  col!=target_column:
                cols_to_drop.append(col)

    preds = prediction.predict_results(prediction_dataset, target_column, dataset, unwanted_cols,
                                       sym_to_replace, thrsh_null,cols_to_drop)  # predict the result for the data loaded

    # render prediction_results.html with the prediction result
    return render_template('prediction_results.html', tables=[preds.head(10).to_html(classes='data', header="True")],
                           columns=preds.columns)
if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000, debug=True)