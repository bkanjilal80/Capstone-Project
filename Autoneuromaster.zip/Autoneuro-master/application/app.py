from flask import Flask, render_template, request, send_file
import pandas as pd
import json
import configparser
import pymongo
from sqlalchemy import create_engine
import pandas as pd

from dataLoad.data_loader import DataGetter
from dataPreprocessing.preProcess import Preprocessor
from dataVisualization.visualization import DataVisualization
from modelTraining.classificationModels import ClassificationModelTuner
from modelTraining.regressionModels import RegressionModelTuner
from prediction.predict import Prediction
from deployment.aws_deployment import AWSAutoDeploy

app = Flask(__name__)

# All class instantiation
data_getter = DataGetter()
preprocessor = Preprocessor()

# visuals = DataVisualization()
classification_model = ClassificationModelTuner()
regression_model = RegressionModelTuner()
prediction = Prediction()
deploy = AWSAutoDeploy()
Predconfig = configparser.ConfigParser()

# cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'r+')
# Predconfig.read("ClientDeploymentFiles/prediction_configurations")

@app.route('/', methods=['GET'])
def index():
    """
                              Method Name: index
                              Description: starting point of app.py code which redirect you to the index.html page
                              where you can select the format of data and upload it for further process
                              Output: index html page.
                              On Failure: Raise Exception
                              Written By: iNeuron Intelligence
                              Revisions: None
                              """
    return render_template('index.html')


@app.route('/load_data', methods=['POST'])
def load_data_from_source():
    """
                                Method Name: load_data_from_source
                                Description: describes data frame infomation as below:
                                             	The number of rows
                                             	The number of columns
                                             	Number of missing values per column and their percentage
                                             	Total missing values and it’s percentage
                                             	Number of categorical columns and their list
                                             	Number of numerical columns and their list
                                             	Number of duplicate rows
                                             	Number of columns with zero standard deviation and their list
                                                 Size occupied in RAM
                                Output: tables.html page
                                On Failure: Raise Exception
                                Written By: iNeuron Intelligence
                                Revisions: None
                       """
    # declared as a global variable
    global no_of_independent_variables
    try:
        global dataset
        if request.files['filename'] is not None:
            file = request.files['filename']  # File can be obtained from request.files

        file_type = request.form['source']  # File Source can be obtained here
        db_type=request.form['source_db']
        # print(file,file_type)
        if request.form['delimiter'] is not None:
            delimeter = str(request.form['delimiter'])
         # Declare global variable
        """
            if request.form['file'] is None and request.form['file_type'] is  None:
            data_getter = DataGetter()  # instantiation for genrating preprocessing logs
            dataset = data_getter.get_data(file_type, file, delimeter)
        """
        if file_type=="DB" and db_type=="mongo_db":
            try:
                root = request.form['content']
                password = request.form['content1']
                dataset = request.form['content2']
                data = request.form['content3']
                dbConn = pymongo.MongoClient(
                    "mongodb://" + root + "/" + password)  # have to provide  thier respective host ID,connection to the mongo DB server
                db = dbConn[dataset]
                test = db[data]  # have to provide their collection name,accessing the collection inside that data base
                dataset = pd.DataFrame(list(test.find()))  # converting the collection to DataFrame

                dataset.drop(columns=['_id'],axis=1,inplace=True)

                preprocessor = Preprocessor()  # instantiation for genrating preprocessing logs
                data_profile = preprocessor.get_data_profile(dataset)
                return render_template('tables.html', tables=[dataset.head(10).to_html(classes='data', header="True")],columns=dataset.columns,profile=data_profile)
            except Exception as e:
                print('The Exception message is: ', e)
                return render_template('index.html',message="No input entered")
        elif file_type=="DB" and db_type=="mysql":
            try:
                root = request.form['content']
                password = request.form['content1']
                database = request.form['content2']
                table = request.form['content3']
                con = create_engine("mysql+pymysql://"+root+":"+password+"@localhost/"+database)
                sql="SELECT * FROM "+table
                dataset = pd.read_sql(sql, con)
                preprocessor = Preprocessor()  # instantiation for genrating preprocessing logs
                data_profile = preprocessor.get_data_profile(dataset)
                return render_template('tables.html', tables=[dataset.head(10).to_html(classes='data', header="True")],
                                       columns=dataset.columns, profile=data_profile)

            except Exception as e:
                print('The Exception message is: ', e)
                return render_template('index.html',message="No input entered")


        else:
            data_getter = DataGetter()  # instantiation for genrating preprocessing logs
            dataset = data_getter.get_data(file_type, file,delimeter)  # call get_data method, it will load the dataset into dataframe

            # get number of independent variables
            no_of_independent_variables = len(dataset.columns) - 1

            # Setting the config values
            try:
                cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'w')
                Predconfig.read("ClientDeploymentFiles/prediction_configurations")
                if not Predconfig.has_section('Prediction'):
                    Predconfig.add_section('Prediction')
                Predconfig.set('Prediction', 'no_of_independent_variables', str(no_of_independent_variables))
                Predconfig.write(cfgfile)
                cfgfile.close()
            except Exception as e:
                raise Exception(e)

            preprocessor = Preprocessor()  # instantiation for genrating preprocessing logs
            data_profile = preprocessor.get_data_profile(dataset)  # call get_data_profile
            print("preprocessor is done")
            # print(data.head())
            # render template tables.html with the respective dataset

    except Exception as e:
        return render_template("index.html", message="No file selected")
    return render_template('tables.html', tables=[dataset.head(10).to_html(classes='data', header="True")],
                           columns=dataset.columns, profile=data_profile)


@app.route('/start_processing', methods=['POST'])
def start_processing():
    """
                                  Method Name: start_processing
                                  Description: receive the problem type and target column and unwanted columns from tables
                                  html page,generates the correlation table and different types of plots
                                  Output: charts.html page
                                  On Failure: Raise Exception
                                  Written By: iNeuron Intelligence
                                  Revisions: None
                                  """

    global problem_type, target_column, unwanted_cols, sym_to_replace, thrsh_null
    problem_type = request.form['problem_type']  # get problem_type, that can be classification or regression
    target_column = request.form['target_column']  # get target column name
    try:
        unwanted_cols = request.form.getlist('unwanted_cols')  # get unwanted columns
    except:
        unwanted_cols = []
    if request.form['sym_to_replace'] is not None:
        sym_to_replace = str(request.form['sym_to_replace'])
    else:
        sym_to_replace = None
    if request.form['thrsh_null']:
        thrsh_null = int(request.form['thrsh_null'])
    else:
        thrsh_null = int(100)

    global x, y
    preprocessor = Preprocessor()  # instantiation for genrating prediction logs

    try:
        cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'w')
        Predconfig.read("ClientDeploymentFiles/prediction_configurations")
        if not Predconfig.has_section('Prediction'):
            Predconfig.add_section('Prediction')
        Predconfig.set('Prediction', 'problem_type', str(problem_type))
        Predconfig.set('Prediction', 'target_column', str(target_column))
        Predconfig.set('Prediction', 'unwanted_cols', str(unwanted_cols))
        Predconfig.set('Prediction', 'sym_to_replace', str(sym_to_replace))
        Predconfig.set('Prediction', 'thrsh_null', str(thrsh_null))
        Predconfig.set('Prediction', 'dataset', str(dataset.columns.tolist()))
    except Exception as e:
        raise Exception(e)

    # getting the list of independant variables from the dataset
    cols = dataset.columns.tolist()
    cols.remove(target_column)
    if len(cols) > 20:
        Predconfig.set('Prediction', 'first_20_expected_pred_file_columns', str(cols[:20]))
    else:
        Predconfig.set('Prediction', 'first_20_expected_pred_file_columns', str(cols))

    Predconfig.write(cfgfile)
    cfgfile.close()

    x, y, vif, ols_summary = preprocessor.preprocess(dataset, target_column, unwanted_cols, sym_to_replace,
                                   thrsh_null,problem_type)  # Calling preprocess method of preprocessor class
    visuals = DataVisualization()  # instatiating object here to initiate logging.
    hmap = visuals.correlation_heatmap(x)
    balance_plot = visuals.balance_imbalance_check(dataset,target_column)
    return render_template('charts.html', hmap=hmap, balance_plot=balance_plot, problem_type=problem_type,
                           tables=[vif.to_html(classes='data', header="True")],
                            ols_table1=[ols_summary.tables[0].as_html()],
                           ols_table2=[ols_summary.tables[1].as_html()],
    ols_table3=[ols_summary.tables[2].as_html(classes='data', header="True")])



@app.route('/build_model', methods=['POST'])
def build_model():
    """
                                       Method Name: build_model
                                       Description:generates the performance report of both the test and train data
                                       for both the classification and regression problems
                                       Output: model_report.html page in case if any thing fails inside the if condition
                                       then index.html age is returned
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    # if problem type is classification, then get the best model with the classification report, else render index.html
    global used_cols, unused_cols
    used_cols, unused_cols = preprocessor.get_used_columns_for_training(dataset, x)

    try:
        cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'w')
        Predconfig.read("ClientDeploymentFiles/prediction_configurations")
        if not Predconfig.has_section('Prediction'):
            Predconfig.add_section('Prediction')
        unused_cols_config = " ".join(unused_cols).replace(" ", ",")
        Predconfig.set('Prediction', 'unused_cols', str(unused_cols_config))
        Predconfig.write(cfgfile)
        cfgfile.close()
    except Exception as e:
        raise Exception(e)

    if problem_type == 'Classification':
        # classification_model=ClassificationModelTuner()#logs for classification modelling
        output = classification_model.get_best_model(x, y)
        print(output)
        model_name = output['Model_name']
        del output['Model_name']
        print(output)
        return render_template('model_report_classification.html', model_name=model_name,
                               reports = output,used_cols=used_cols.tolist(), unused_cols=unused_cols)
                               #tables=[confusion_mat.to_html(classes='data', header="True")]

    else:

        output= regression_model.get_best_model(x, y)
        print(output)
        model_name = output['Model_name']
        del output['Model_name']
        print(output)


        return render_template('model_report_regression.html', model_name=model_name,
                               reports = output, used_cols=used_cols.tolist(), unused_cols=unused_cols)


@app.route('/try_prediction', methods=['POST'])
def try_predict():
    """
                                       Method Name: try_predict
                                       Description: provides the html page for providing the data for prediction,give your prediction data here.
                                       Output: prediction.html page
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    return render_template('prediction.html')


def verify_prediction_columns(prediction_dataset):
    # getting values from configuration file
    cfgfile = open("ClientDeploymentFiles/prediction_configurations", 'r+')
    Predconfig.read("ClientDeploymentFiles/prediction_configurations")
    if not Predconfig.has_section('Prediction'):
        Predconfig.add_section('Prediction')
    no_of_cols_expected = Predconfig.getint('Prediction', 'no_of_independent_variables')
    expected_cols = Predconfig.get('Prediction', 'first_20_expected_pred_file_columns')
    cfgfile.close()

    # Validation the columns in predition dataset
    if len(prediction_dataset.columns) != no_of_cols_expected:
        return (True,no_of_cols_expected,expected_cols)
    return (False,0,0)


@app.route('/predict', methods=['POST','GET'])
def predict():
    """
                                       Method Name: predict
                                       Description: takes the prediction data from prediction.html page
                                       and perform same kind of transformation as the train  and test data set
                                       and provides prediction result
                                       Output: prediction_results.html page
                                       On Failure: Raise Exception
                                       Written By: iNeuron Intelligence
                                       Revisions: None
                                       """
    global prediction_dataset
    if request.method == "POST":
        try:
            file = request.files['prediction_filename']  # get prediction file
            file_type = request.form['source']  # get file type
            if request.form['delimiter'] is not None:
                delimeter = str(request.form['delimiter'])
            data_getter = DataGetter()
            prediction_dataset = data_getter.get_data(file_type, file, delimeter)  # Matching with function definition
        except:
            try:
                json_data = json.loads(request.form['pred_request'])

                prediction_dataset = pd.read_json(json_data)
            except:
                json_data = None

        wrong_prediction_columns,no_of_cols_expected,expected_cols = verify_prediction_columns(prediction_dataset)

        if wrong_prediction_columns:
            message = "There should be {} columns in the prediction file. But found {} columns.".format(
                    no_of_cols_expected, len(prediction_dataset.columns))

            if no_of_cols_expected <= 20:
                message1 = "The file must contain the following columns only:"
                return render_template('prediction.html', error_message=message, error_message1=message1,column_names=expected_cols)
            else:
                message1 = "The 1st 20 columns expected in the prediction file are: "
                return render_template('prediction.html', error_message=message, error_message1=message1,column_names=expected_cols)


        prediction = Prediction()
        print(used_cols.tolist())
        original_prediction_dataset = prediction_dataset
        prediction_dataset = prediction_dataset.loc[:,used_cols.tolist()]
        print(prediction_dataset.head())
        preds = prediction.predict_results(prediction_dataset, original_prediction_dataset, target_column, dataset.columns, unwanted_cols,
                                           sym_to_replace, thrsh_null, problem_type)  # predict the result for the data loaded
        #Saving the predictions to .csv file
        preds.to_csv('prediction_results.csv')

        # render prediction_results.html with the prediction result
        return render_template('prediction_results.html', tables=[preds.head(10).to_html(classes='data', header="True")],
                               columns=preds.columns)

    ## for downloading prediction results
    elif request.method == "GET":
        try:
            file_path = "prediction_results.csv"
            return send_file(file_path, as_attachment=True)
        except Exception as e:
            raise Exception(e)


@app.route('/select_cloud', methods=['POST'])
def select_cloud():
    cloud_name = request.form['cloud_name']
    if cloud_name == 'aws':
        return render_template('AWSDeploymentLogin.html')


@app.route('/aws_deploy', methods=['POST'])
def ValidateCredentials():
    try:
        # get values from UI
        Accesskey = request.form['Accesskey']
        Accesspassword = request.form['SecretAccessKey']
        if (Accesskey is not None and Accesspassword is not None):
            url = deploy.ValidateCredentials(Accesskey, Accesspassword, "ap-south-1")
            #return url
            return render_template('aws_url.html',url=url)
        else:
            return "Credentials are Mandatory"
    except Exception as e:
        return render_template('500.html')


if __name__ == '__main__':
    app.run(debug=True)
