import boto3
import paramiko
from scp import SCPClient, SCPException
import os,os.path
import pickle
import time
import configparser
from logger.appLogger import AppLogger

class AWSAutoDeploy:
    """

        This class shall be used to AutoDeploy in Cloud environment
        Written By: iNeuron Intelligence
        Version: 1.0
        Revisions: None

    """

    def __init__(self):
        self.logger_object=AppLogger()
        self.config = configparser.ConfigParser()
        self.config.read("aws_configurations")
        self.KeyName = self.config['AWS']['KeyName']
        self.KeyFilePath = self.config['AWS']['KeyFilePath']
        self.ImageId = self.config['AWS']['ImageId']
        self.MinCount = self.config['AWS']['MinCount']
        self.MaxCount = self.config['AWS']['MaxCount']
        self.InstanceType = self.config['AWS']['InstanceType']
        self.SecurityGroup = self.config['AWS']['SecurityGroup']
        self.SecurityGroupDesc = self.config['AWS']['SecurityGroupDesc']
        self.InstanceFile = self.config['AWS']['InstanceFile']
        self.InstanceState = self.config['AWS']['InstanceState']
        self.InstanceStatus = self.config['AWS']['InstanceStatus']
        self.SystemStatus = self.config['AWS']['SystemStatus']
        self.InstanceFilePath = self.config['AWS']['InstanceFilePath']
        self.RemotePath = self.config['AWS']['RemotePath']
        self.ApplicationPath = self.config['AWS']['ApplicationPath']
        self.UserName = self.config['AWS']['UserName']
        self.Port = self.config['AWS']['Port']
        self.PythonInstallation = self.config['AWSCommands']['PythonInstallation']
        self.RequirementsInstallation = self.config['AWSCommands']['RequirementsInstallation']
        self.ServiceRunning = self.config['AWSCommands']['ServiceRunning']
        self.YesOrNO = self.config['AWSCommands']['YesOrNO']
        self.AptUpdations = self.config['AWSCommands']['AptUpdations']
        self.SecurityGroupId = None


    def ValidateCredentials(self,AccessKeyId,AccessPassword,Region):
        file_object = open('logs/deploymentlogs.txt', 'a+')
        try:
            session = boto3.session.Session(region_name=Region, aws_access_key_id=AccessKeyId,aws_secret_access_key=AccessPassword)
            self.ec2resource = session.resource('ec2')
            self.ec2client = session.client('ec2')
            self.Region=Region
            try:
                response = self.ec2client.describe_instances()
            except Exception as e:
                self.logger_object.log(file_object,"Please enter valid credentials."+str(e))
                return "Please Enter valid Credentials"
            self.logger_object.log(file_object, "Credentials are successfully validated")
            self.logger_object.log(file_object, "AutoDeploy Method is about to run")
            url= self.Deploy()
            return url

        except Exception as e:
            self.logger_object.log(file_object,"It seems object is not initilized.Please enter valid credentials."+str(e))
            raise Exception()
        return url

    def CreateNewInstance(self):
        instances = self.ec2resource.create_instances(
            ImageId=str(self.ImageId),
            MinCount=int(self.MinCount),
            MaxCount=int(self.MaxCount),
            InstanceType=str(self.InstanceType),
            KeyName=str(self.KeyName),
            SecurityGroupIds=[
                str(self.SecurityGroupId)
            ]
            )
        id = str(instances).split("id='")[1][0:-3]
        with open(os.path.abspath(os.path.join(self.InstanceFilePath,self.InstanceFile)), 'wb') as f:
            pickle.dump(id, f)
        return id

    def CreateSecurityGroups(self):
        vpcresponse = self.ec2client.describe_vpcs()
        vpc_id = vpcresponse.get('Vpcs', [{}])[0].get('VpcId', '')
        SecGroupresponse = self.ec2client.describe_security_groups()
        for (GName, GId) in [(Groups['GroupName'], Groups['GroupId']) for Groups in SecGroupresponse['SecurityGroups']]:
            if (GName == self.SecurityGroup):
                self.SecurityGroupId = GId
        if self.SecurityGroupId is None and vpc_id is not None:
            GResponse = self.ec2client.create_security_group(GroupName=self.SecurityGroup,
                                                        Description=self.SecurityGroupDesc,
                                                        VpcId=vpc_id)
            self.SecurityGroupId = GResponse['GroupId']
            if self.SecurityGroupId is not None:
                data = self.ec2client.authorize_security_group_ingress(
                    GroupId=self.SecurityGroupId,
                    IpPermissions=[
                        {'IpProtocol': '-1',
                         'IpRanges': [{'CidrIp': '0.0.0.0/0'}],
                         'Ipv6Ranges': [{'CidrIpv6': '::/0'}]

                         }
                    ]

                )



    def uploadfiles(self,ScpObject, file):
        ScpObject.put(file, recursive=True, remote_path=str(self.RemotePath))
        file_object = open('logs/deploymentlogs.txt', 'a+')
        self.logger_object.log(file_object, "Successfully Uploaded : "+str(file))


    def Deploy(self):
        instance = None
        id = None
        PublicIpAddress = None
        PublicDnsName = None
        PrivateKeyFile = None
        Key_path=None
        file_object = open('logs/deploymentlogs.txt', 'a+')
        response = self.ec2client.describe_key_pairs()
        KeyPairs = [Keys['KeyName'] for Keys in response['KeyPairs']]
        for key in KeyPairs:
            if key == self.KeyName:
                if os.path.isfile(os.path.abspath(os.path.join(self.KeyFilePath,self.KeyName))):
                    Key_path=os.path.abspath(os.path.join(self.KeyFilePath,self.KeyName))
                    self.logger_object.log(file_object, "already key is Existed:"+str(Key_path))
        if Key_path is None:
            AutorneuroKey = self.ec2client.create_key_pair(KeyName=self.KeyName)
            self.KeyFilePath=os.path.abspath(os.path.join(self.KeyFilePath,self.KeyName))
            print(self.KeyFilePath)
            with open(self.KeyFilePath, 'w') as file:
                file.write(AutorneuroKey['KeyMaterial'])
        self.CreateSecurityGroups()

        if os.path.isfile(os.path.abspath(os.path.join(self.InstanceFilePath,self.InstanceFile))):
            with open(os.path.abspath(os.path.join(self.InstanceFilePath,self.InstanceFile)), 'rb') as f:
                id = pickle.load(f)
            instance = self.ec2resource.Instance(id)
        if id is None:
            id = self.CreateNewInstance()
            instance = self.ec2resource.Instance(id)
        self.logger_object.log(file_object, "Please wait instance is initilizing. It will take a while")
        #print("Please wait instance is initilizing.It will take a while...")
        self.CheckInstanceStatus(id)

        if instance is not None:
            self.logger_object.log(file_object, "Instance is connecting..")
            PublicIpAddress = instance.public_ip_address
            PublicDnsName = instance.public_dns_name
            self.logger_object.log(file_object,"PublicIpAddress:" + str(PublicIpAddress)+",PublicDnsName:"+str(PublicDnsName))
            PrivateKeyFile = paramiko.RSAKey.from_private_key_file(os.path.abspath(os.path.join(self.KeyFilePath,'')))
            #PrivateKeyFile='D:\\datascience\\iNeuron\\internship\\autoneuro\\Autoneuro_git\\application\\deployment\\AutoNeuro_key_t'
            sshclient = paramiko.SSHClient()
            sshclient.set_missing_host_key_policy(paramiko.AutoAddPolicy())
            sshclient.connect(hostname=PublicIpAddress, username=self.UserName, pkey=PrivateKeyFile)
            scp = SCPClient(sshclient.get_transport())
            self.logger_object.log(file_object, "Files upload initializing..")
            #self.ApplicationPath=os.join(os.getcwd(),self.ApplicationPath)
            for file in os.listdir(str(self.ApplicationPath)):
                self.uploadfiles(scp, os.path.join(self.ApplicationPath, file))
            listcmd=[str(self.PythonInstallation),str(self.RequirementsInstallation),str(self.AptUpdations),str(self.ServiceRunning)]
            for cmd in listcmd:
                self.logger_object.log(file_object, cmd)
                stdin, stdout, stderr = sshclient.exec_command(str(cmd))
                if str(cmd)==str(self.ServiceRunning):
                    break
                print(stdout.read())

            self.logger_object.log(file_object, 'http://' + PublicDnsName + ':8000/')
            return 'http://' + PublicDnsName + ':8000/'

        else:
            self.logger_object.log(file_object, 'Instance is not initialized')
            return  "Instance is not initialized"

    def CheckInstanceStatus(self,id):
        print("checkingStatus")
        t_end = time.time() + 60 * 4
        status=None
        while True:
            StutusChecks = self.ec2client.describe_instance_status(
                InstanceIds=[id],
                IncludeAllInstances=True
            )
            InsStatus = StutusChecks['InstanceStatuses'][0]['InstanceStatus']['Status']
            SysStatus = StutusChecks['InstanceStatuses'][0]['SystemStatus']['Status']
            InsState = StutusChecks['InstanceStatuses'][0]['InstanceState']['Name']
            if str(InsStatus) ==str(self.InstanceStatus) and str(SysStatus) == str(self.SystemStatus) and str(InsState) == str(self.InstanceState):
                status = True
                break
            if time.time() >= t_end:
                status = False
                break










